function fun()
{
alert("Finding the best trains."); 
alert("To proceed click ok");
}